function [ output ] = X_optimize_example(x)
    output = (x(1)-2).^2 + (x(2)-10).^2;
end

